#include "TestPlayer.h"
#include "defines.h"
#include <iostream>

using namespace std;

int main() {
	TestPlayerV2 player(8);
	/* cout << "natty" << endl;
	player.printProbMap(); */

	Direction test = None;
	if (test == Vertical) {
		cout << "Vertical";
	} else {
		cout << "None";
	}
	cout << endl;

	player.printProbMap();
	player.newRound();
	Message result = player.getMove();

	Message testMesg(HIT, 2, 2, "nat", None, 0);
	player.update(testMesg);
	player.getMove();

	Message testMesg2(HIT, 2, 3, "nat", None, 0);
	player.update(testMesg2);
	player.getMove();

	Message testMesg3(HIT, 2, 4, "nat", None, 0);
	player.update(testMesg3);
	player.getMove();

	Message testMesg7(HIT, 2, 5, "nat", None, 0);
	player.update(testMesg7);
	player.getMove();

	Message testMesg4(KILL, 2, 6, "nat", None, 3);
	player.update(testMesg4);
	Message testMesg5(KILL, 2, 4, "nat", None, 3);
	player.update(testMesg5);
	Message testMesg6(KILL, 2, 5, "nat", None, 3);
	player.update(testMesg6);
	player.getMove();


}
