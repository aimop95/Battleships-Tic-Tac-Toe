/**
 * @brief DumbPlayer AI for battleships
 * @file DumbPlayerV2.cpp
 * @author Stefan Brandle, Jonathan Geisler
 * @date September, 2004 Updated 2015 for multi-round play.
 *
 * This Battleships AI is very simple and does nothing beyond playing
 * a legal game. However, that makes it a good starting point for writing
 * a more sophisticated AI.
 *
 * The constructor
 */

#include <iostream>
#include <cstdio>
#include <vector>
#include <list>
#include <cstdlib>

#include "conio.h"
#include "TestPlayer.h"

using namespace conio;

/**
 * @brief Constructor that initializes any inter-round data structures.
 * @param boardSize Indication of the size of the board that is in use.
 *
 * The constructor runs when the AI is instantiated (the object gets created)
 * and is responsible for initializing everything that needs to be initialized
 * before any of the rounds happen. The constructor does not get called 
 * before rounds; newRound() gets called before every round.
 */

TestPlayerV2::TestPlayerV2( int boardSize )
    :PlayerV2(boardSize)
{
	this->smallestShipSize = MAX_BOARD_SIZE;

	//initialize probability maps
	initializeProbMap(opponentsHits);
	initializeProbMap(ourHits);

	srand(time(NULL));
}

/**
 * @brief Destructor placeholder.
 * If your code does anything that requires cleanup when the object is
 * destroyed, do it here in the destructor.
 */
TestPlayerV2::~TestPlayerV2( ) {}

/*
 * Private internal function that initializes a MAX_BOARD_SIZE 2D array of char to water.
 */
void TestPlayerV2::initializeBoard() {
    for(int row=0; row<boardSize; row++) {
	for(int col=0; col<boardSize; col++) {
	    this->roundBoard[row][col] = WATER;
	}
    }
}

void TestPlayerV2::initializeProbMap(int probMap[MAX_BOARD_SIZE][MAX_BOARD_SIZE]) {
	int edge = boardSize - 1;

	//corners
	probMap[0][0] = 2;
	probMap[0][edge] = 2;
	probMap[edge][0] = 2; 
	probMap[edge][edge] = 2;
	
	//edges
	for (int i = 1; i < edge; i++) {
		probMap[0][i] = 3;
		probMap[edge][i] = 3;
		probMap[i][0] = 3;
		probMap[i][edge] = 3;
	}

	//the rest of the board
	for (int row = 1; row < edge; row++) {
		for (int col = 1; col < edge; col++) {
			probMap[row][col] = 4;
		}
	}
}

void TestPlayerV2::printProbMap() {
	for (int row = 0; row < boardSize; row++) {
		for (int col = 0; col < boardSize; col++) {
			cout << ourHits[row][col] << " ";
		}
		cout << endl;
	}

	//print follow up
	cout << "follow up size: " << followUp.positions.size() << endl;
}


/**
 * @brief Specifies the AI's shot choice and returns the information to the caller.
 * @return Message The most important parts of the returned message are 
 * the row and column values. 
 *
 * See the Message class documentation for more information on the 
 * Message constructor.
 */
Message TestPlayerV2::getMove() {
	//all possible locations to shoot at
	vector<Position> possibleShots;

	//choose possible locations by following up on a hit
	if (followUp.active) {
		addAdjacentLocations(possibleShots, followUp.direction, followUp.positions.back());		

		//if we didn't find any adjacent locations, go down the stack looking
		//for other adjacent locations
		while (possibleShots.empty() && followUp.positions.size() > 1) {
			followUp.positions.pop_back();
			addAdjacentLocations(possibleShots, followUp.direction, followUp.positions.back());
		}

		//if there still aren't any valid adjacent locations even after going
		//through the whole stack, then switch directions
		if (possibleShots.empty()) {
			if (followUp.direction == Vertical) {
				followUp.direction = Horizontal;
			} else if (followUp.direction == Horizontal) {
				followUp.direction = Vertical;
			}
			addAdjacentLocations(possibleShots, followUp.direction, followUp.positions.back());
		}
	}
	//if we're not following up, or followup didn't find anything, then choose possible locations
	//just by looking for any valid on the board
	if (possibleShots.empty()) {

		//let's just try clearing followup...
		/* followUp.active = false;
		followUp.direction = None;
		followUp.positions.clear();
		followUp.hitPositions.clear(); */

		for (int row = 0; row < boardSize; row++) {
			for (int col = (row%smallestShipSize); col < boardSize; col+=smallestShipSize) {
				//only add it if it hasn't been shot at yet
				if (roundBoard[row][col] == WATER) {
					Position pos = {row, col};
					possibleShots.push_back(pos);
				}
			}
		}
	}

	//print out possible shots
/*	cout << "Possible Shots" << endl;
	for (int i = 0; i < possibleShots.size(); ++i) {
		cout << possibleShots.at(i).row << ", " << possibleShots.at(i).col << endl;
	} */

	//make a new vector of possible shots adjusted for probability. Shots that
	//are more probable hits are added more times so there's a greater chance
	//of them being chosen
	vector<Position> possibleShotsProb;
	for (int i = 0; i < possibleShots.size(); i++) {
		Position currentPos = possibleShots.at(i);
		int probability = ourHits[currentPos.row][currentPos.col];
		for (int counter = 0; counter < probability; counter++) {
			possibleShotsProb.push_back(currentPos);
		}
	}

	//print out possible shots prob
/*	cout << "Possible Shots w Probabilities" << endl;
	for (int i = 0; i < possibleShotsProb.size(); ++i) {
		cout << possibleShotsProb.at(i).row << ", " << possibleShotsProb.at(i).col << endl; 
	} */

 	/* for (int row = 0; row < boardSize; row++) {
		for (int col = 0; col < boardSize; col++) {
			//only add it if it hasn't been shot at yet
			if (roundBoard[row][col] == WATER) {
				//add to the vector as many times as its probability ranking,
				//so that there will be a greater chance of it being chosen
				Position position = {row, col};
				for (int i = 0; i < ourHits[row][col]; i++) {
					possibleShots.push_back(position);
				}
			}
		}
	} */

	//generate a random number corresponding to one of the positions in the
	//list
	int random = rand() % possibleShotsProb.size();
	//and get that random position
	Position randomPos = possibleShotsProb.at(random);

//	cout << "chosen pos: " << randomPos.row << ", " << randomPos.col << endl;

	roundBoard[randomPos.row][randomPos.col] = SHOT;
	Message result(SHOT, randomPos.row, randomPos.col, "Bang", None, 1);
	return result;
	
	/* cout << "random pos: " << randomPos.row << ", " << randomPos.col << endl;

	cout << "possible shots size: " << possibleShots.size() << endl; */

	/* for (int i = 0; i < possibleShots.size(); i++) {
		Position pos = possibleShots.at(i);
		cout << pos.row << ", " << pos.col << endl;
	} */

    /* Message result( SHOT, 0, 0, "Bang", None, 1 );
    return result; */
}

void TestPlayerV2::addAdjacentLocations(vector<Position>& posList, Direction direction, Position position) {
	if (direction == Horizontal || direction == None) {
		if (((position.col + 1) < boardSize) && (roundBoard[position.row][position.col + 1] == WATER)) {
			Position pos = {position.row, position.col + 1};
			posList.push_back(pos);
		}
		if (((position.col - 1) >= 0) && (roundBoard[position.row][position.col - 1] == WATER)) {
			Position pos = {position.row, position.col - 1};
			posList.push_back(pos);
		}
	}

	if (direction == Vertical || direction == None) {
		if (((position.row + 1) < boardSize) && (roundBoard[position.row + 1][position.col] == WATER)) {
			Position pos = {position.row + 1, position.col};
			posList.push_back(pos);
		}
		if (((position.row - 1) >= 0) && (roundBoard[position.row - 1][position.col] == WATER)) {
			Position pos = {position.row - 1, position.col};
			posList.push_back(pos);
		}
	}
}

/**
 * @brief Tells the AI that a new round is beginning.
 * The AI show reinitialize any intra-round data structures.
 */
void TestPlayerV2::newRound() {
    /* DumbPlayer is too simple to do any inter-round learning. Smarter players 
     * reinitialize any round-specific data structures here.
     */
   // this->lastRow = 0;
   // this->lastCol = -1;
    this->numShipsPlaced = 0;
	this->smallestShipSize = MAX_BOARD_SIZE;
	this->followUp.active = false;
	this->followUp.direction = None;
	this->followUp.positions.clear();
	this->shipsPlaced.clear();

    this->initializeBoard();
}

/**
 * @brief Gets the AI's ship placement choice. This is then returned to the caller.
 * @param length The length of the ship to be placed.
 * @return Message The most important parts of the returned message are 
 * the direction, row, and column values. 
 *
 * The parameters returned via the message are:
 * 1. the operation: must be PLACE_SHIP 
 * 2. ship top row value
 * 3. ship top col value
 * 4. a string for the ship name
 * 5. direction Horizontal/Vertical (see defines.h)
 * 6. ship length (should match the length passed to placeShip)
 */

bool TestPlayerV2::placeVerify( int row, int col ){
	int size = static_cast<int>(shipsPlaced.size());
	for( int i = 0; i < size; i++) {
		if ( row == shipsPlaced[i][row] || col == shipsPlaced[i][col] ) {
			return false;
		}
	}
	return true;
}

Message TestPlayerV2::placeShip(int length) {
/*	Message response( PLACE_SHIP, boardSize - length, numShipsPlaced, "natty ship", Vertical, length );
    numShipsPlaced++;
    return response;*/

	if (length < smallestShipSize) {
		smallestShipSize = length;
	}
	
	int horizMin = 999;
	int vertMin = 999;
	vector< vector<int> > horizPlacements(MAX_BOARD_SIZE * MAX_BOARD_SIZE, vector<int>(2)); //This vector will act as a list to store [row][col] pairs
	vector< vector<int> > vertPlacements(MAX_BOARD_SIZE * MAX_BOARD_SIZE, vector<int>(2)); //This vector will act as a list to store [row][col] pairs
	int probSum = 0;
    char shipName[10];

    // Create ship names each time called: Ship0, Ship1, Ship2, ...
    snprintf(shipName, sizeof shipName, "Ship%d", numShipsPlaced);

    // parameters = mesg type (PLACE_SHIP), row, col, a string, direction (Horizontal/Vertical)

	for (int row = 0; row <= MAX_BOARD_SIZE - length; row++) { //First, we calculate the optimal placement for a horizontal ship
		for (int col = 0; col < MAX_BOARD_SIZE; col++) {
			for (int shipPart = 0; shipPart < length; shipPart++) {
				probSum += opponentsHits[row][col+shipPart];
			}
			if (probSum < horizMin && placeVerify(row, col) ) { //If sum < minimum, this is obviously the most optimal placement we've found. Erase what we have and
				horizMin = probSum;   //mark this as the best placement so far
				horizPlacements.clear();
//				vector<int> "loc%d", (horizPlacements.size() + 1)(2);
				vector<int> locList(2);
				locList.push_back(row);
				locList.push_back(col);
				horizPlacements.push_back(locList);
/*				horizPlacements.resize(MAX_BOARD_SIZE * MAX_BOARD_SIZE);
				horizPlacements[0][0] = row;
				horizPlacements[0][1] = col;
				numElements = 1;*/
			}
			else if (probSum == horizMin) { //If the sum == minimum, this is a possible location for our randomizer. Slap that location on there.
				vector<int> locList(2);
				locList.push_back(row);
				locList.push_back(col);
				horizPlacements.push_back(locList);
/*				horizPlacements[numElements][0] = row;
				horizPlacements[numElements][1] = col;
				numElements++;*/
			}
		}
	}


	for (int col = 0; col <= MAX_BOARD_SIZE - length; col++) { //Now we do the same for a vertical ship
		for (int row = 0; row < MAX_BOARD_SIZE; row++) {
			for (int shipPart = 0; shipPart < length; shipPart++) {
				probSum += opponentsHits[row+shipPart][col];
			}
			if (probSum < vertMin) { //If sum < minimum, this is obviously the most optimal placement we've found. Erase what we have and
				vertMin = probSum;   //mark this as the best placement so far
				vertPlacements.clear();
//				vector<int> "loc%d", (vertPlacements.size() + 1)(2);
				vector<int> locList(2);
				locList.push_back(row);
				locList.push_back(col);
				vertPlacements.push_back(locList);
/*				vertPlacements.resize(MAX_BOARD_SIZE * MAX_BOARD_SIZE);
				vertPlacements[0][0] = row;
				vertPlacements[0][1] = col;
				numElements = 1;*/
			}
			else if (probSum == vertMin) { //If the sum == minimum, this is a possible location for our randomizer. Slap that location on there.
				vector<int> locList(2);
				locList.push_back(row);
				locList.push_back(col);
				vertPlacements.push_back(locList);
/*				vertPlacements[numElements][0] = row;
				vertPlacements[numElements][1] = col;
				numElements++;*/
			}
		}
	}

	if (horizMin > vertMin) { //Here, we see if it's smarter to place a horizontal or vertical ship
		int randPos = ( rand() % horizPlacements.size() );
		Message response( PLACE_SHIP, horizPlacements[randPos][0], horizPlacements[randPos][1], shipName, Horizontal, length);
		vector<int> locList(2);
		locList.push_back(horizPlacements[randPos][0]);
		locList.push_back(horizPlacements[randPos][1]);
		shipsPlaced.push_back(locList);
		return response;
	}
	else if (horizMin < vertMin) {
		int randPos = ( rand() % vertPlacements.size() );
		Message response( PLACE_SHIP, vertPlacements[randPos][0], vertPlacements[randPos][1], shipName, Vertical, length);
		vector<int> locList(2);
		locList.push_back(vertPlacements[randPos][0]);
		locList.push_back(vertPlacements[randPos][1]);
		shipsPlaced.push_back(locList);
		return response;
	}
	else { //If both minimums are equal, it doesn't matter
		int randDir = ( rand() % 2 );
		if (randDir == 0) {
			int randPos = ( rand() % horizPlacements.size() );
			Message response( PLACE_SHIP, horizPlacements[randPos][0], horizPlacements[randPos][1], shipName, Horizontal, length);
			vector<int> locList(2);
			locList.push_back(horizPlacements[randPos][0]);
			locList.push_back(horizPlacements[randPos][1]);
			shipsPlaced.push_back(locList);
			return response;
		}
		else {
			int randPos = ( rand() % vertPlacements.size() );
			Message response( PLACE_SHIP, vertPlacements[randPos][0], vertPlacements[randPos][1], shipName, Vertical, length);
			vector<int> locList(2);
			locList.push_back(vertPlacements[randPos][0]);
			locList.push_back(vertPlacements[randPos][1]);
			shipsPlaced.push_back(locList);
			return response;
		}
	}
	//Below is Dumb Player being dumb, but we still need to use its response format

    /*Message response( PLACE_SHIP, numShipsPlaced, 0, shipName, Horizontal, length );
    numShipsPlaced++;
    return response;*/
}

/**
 * @brief Updates the AI with the results of its shots and where the opponent is shooting.
 * @param msg Message specifying what happened + row/col as appropriate.
 */
void TestPlayerV2::update(Message msg) {
    switch(msg.getMessageType()) {
	case HIT: {
		roundBoard[msg.getRow()][msg.getCol()] = msg.getMessageType();

		//update probabilities
		ourHits[msg.getRow()][msg.getCol()]++;

		followUp.active = true;
		Position thisPos = {msg.getRow(), msg.getCol()};
		followUp.hitPositions.push_back(thisPos);

		//if there was already a hit in the followup chain, set the direction
		if (followUp.positions.size() > 0) {
			Position prevPos = followUp.positions.back();

			if (prevPos.row == thisPos.row) {
				followUp.direction = Horizontal;
			} else if (prevPos.col == thisPos.col) {
				followUp.direction = Vertical;
			}
		}

		followUp.positions.push_back(thisPos);
	} break;
	case KILL: {
		roundBoard[msg.getRow()][msg.getCol()] = msg.getMessageType();
		
		//see if there any hits that we didn't deal with
		//clear direction in order to follow up properly on any leftover hits
		followUp.direction = None;

		//copy the list of hit positions over to the followup stack
		followUp.positions = vector<Position>(followUp.hitPositions);
		//delete this killed position from both
		for (int i = 0; i < followUp.positions.size(); ++i) {
			Position currentPos = followUp.positions.at(i);
			if ((currentPos.row == msg.getRow()) && (currentPos.col = msg.getCol())) {
				followUp.positions.erase(followUp.positions.begin() + i);
				followUp.hitPositions.erase(followUp.hitPositions.begin() + i);
				break;
			}
		}

		//if the list of hit positions is empty, the kill has deal with all our hits
		//and so we can deactivate followup
		if (followUp.hitPositions.empty()) {
			followUp.active = false;
			followUp.direction = None;
			followUp.positions.clear();
			followUp.hitPositions.clear();
		}



			/* followUp.active = false;
			followUp.direction = None;
			followUp.positions.clear();
			followUp.hitPositions.clear(); */
			
			//cout << conio::gotoRowCol(20, 30) << "kill at " << msg.getRow() << ", " << msg.getCol() << flush;
	}	break;
	case MISS:
	    roundBoard[msg.getRow()][msg.getCol()] = msg.getMessageType();
	    break;
	case WIN:
	    break;
	case LOSE:
	    break;
	case TIE:
	    break;
	case OPPONENT_SHOT:
	    // TODO: get rid of the cout, but replace in your AI with code that does something
	    // useful with the information about where the opponent is shooting.
	    //cout << gotoRowCol(20, 30) << "DumbPl: opponent shot at "<< msg.getRow() << ", " << msg.getCol() << flush;
	    break;
    }
}

