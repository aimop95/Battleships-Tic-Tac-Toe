/**
 * @author Stefan Brandle, Jonathan Geisler
 * @date September, 2004
 *
 * Please type in your name[s] here:
 *
 */

#ifndef TESTPLAYER_H		// Double inclusion protection
#define TESTPLAYER_H

using namespace std;

#include "PlayerV2.h"
#include "Message.h"
#include "defines.h"
#include <list>
#include <vector>

// DumbPlayer inherits from/extends PlayerV2

struct Position {
	int row;
	int col;
};

struct FollowUp {
	bool active;
	Direction direction;
	list<Position> positions;
	vector<Position> hitPositions;
};

class TestPlayerV2: public PlayerV2 {
    public:
	TestPlayerV2( int boardSize );
	~TestPlayerV2();
	void newRound();
	Message placeShip(int length);
	Message getMove();
	void update(Message msg);

	//functions for testing
	void printProbMap();

    private:
	int opponentsHits[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
	int ourHits[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
	char roundBoard[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
	void initializeBoard();
	void initializeProbMap(int probMap[MAX_BOARD_SIZE][MAX_BOARD_SIZE]);
	bool placeVerify( int row, int col);
	void addAdjacentLocations(vector<Position>& posList, Direction direction, Position position);
	void findUnKilledHit(Position killPos, int killLength);

//        int lastRow;
//        int lastCol;
	int numShipsPlaced;
    char board[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
	vector< vector<int> >shipsPlaced;
	FollowUp followUp;
};

#endif
